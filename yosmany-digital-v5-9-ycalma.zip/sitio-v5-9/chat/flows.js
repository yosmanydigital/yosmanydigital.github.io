/* ============================================================
   Flujos guiados — YOSMANY DIGITAL (asistente de ventas)
   Editar aquí los textos, precios y caminos SIN tocar el motor.
   Precios = escalera sellada de la casa. Nada inventado.
   endpoint: déjalo en '' mientras el Worker no tenga la llave;
   el chat funciona en modo guiado/demo. Al encender el Worker,
   pon su URL aquí (ej. 'https://yosmany-chat.<cuenta>.workers.dev/chat').
   ============================================================ */
window.YD_CHAT_FLOWS = {
  house: 'digital',
  endpoint: '',
  mascot: '/chat/mascota.webp',
  maxUserMsgs: 40,
  proactiveDelayMs: 6000,

  assistantName: { es: 'Asistente de Yosmany Digital', en: 'Yosmany Digital Assistant' },
  proactive: {
    es: '¡Hola! 👋 Soy el asistente de la casa. Si tu negocio pierde llamadas o mensajes sin responder, te muestro en 1 minuto cómo lo resolvemos.',
    en: 'Hi! 👋 I am the house assistant. If your business misses calls or unanswered messages, I can show you in 1 minute how we fix that.'
  },
  proactiveCta: { es: 'Muéstrame', en: 'Show me' },

  fallback: {
    es: 'Eso no lo tengo a la mano y no te voy a inventar una respuesta 🙏. Te dejo los caminos directos: mira los precios con el botón de abajo, o cuéntanos tu caso en el formulario /contacto/ y te responde una persona. También puedes escribir a hola@yosmanydigital.com.',
    en: 'I do not have that handy and I will not make up an answer 🙏. Here are the direct paths: check prices with the button below, or tell us about your case in the form /contacto/ and a person will reply. You can also email hola@yosmanydigital.com.'
  },

  limitChips: [
    { label: { es: '📝 Ir al formulario', en: '📝 Go to the form' }, url: '/contacto/', cta: true },
    { label: { es: '💲 Ver precios', en: '💲 See prices' }, go: 'precios' }
  ],

  nodes: {
    root: {
      say: {
        es: [
          '¡Hola! Bienvenido a Yosmany Digital 👋',
          'Ayudamos a negocios hispanos en EE. UU. a no perder ni un cliente: asistentes de IA que contestan llamadas y chats día y noche, y páginas web que venden.',
          'Esto que estás usando es una muestra de nuestro propio servicio 😉. Toca un botón y te guío paso a paso:'
        ],
        en: [
          'Hi! Welcome to Yosmany Digital 👋',
          'We help Hispanic businesses in the U. stop losing customers: AI assistants that answer calls and chats day and night, plus websites that sell.',
          'What you are using right now is a demo of our own service 😉. Tap a button and I will guide you step by step:'
        ]
      },
      chips: [
        { label: { es: '📞 Pierdo llamadas', en: '📞 I miss calls' }, go: 'pierdo' },
        { label: { es: '🤖 Quiero un chat con IA', en: '🤖 I want an AI chat' }, go: 'chat' },
        { label: { es: '🗣️ Chat + voz', en: '🗣️ Chat + voice' }, go: 'voz' },
        { label: { es: '🌐 Necesito una página web', en: '🌐 I need a website' }, go: 'web' },
        { label: { es: '💲 Precios', en: '💲 Prices' }, go: 'precios' },
        { label: { es: '🙋 Hablar con una persona', en: '🙋 Talk to a person' }, go: 'humano' }
      ]
    },

    pierdo: {
      say: {
        es: [
          'Ese es justo nuestro método: el «Método Sin Llamada Perdida» 🎯',
          'Cada llamada o mensaje sin responder es un cliente que se va con la competencia. Instalamos un asistente que contesta por ti 24/7, en español e inglés, captura los datos del cliente y agenda la cita.',
          '¿Dónde pierdes más clientes?'

        ],
        en: [
          'That is exactly our method: the "Never Miss a Call Method" 🎯',
          'Every unanswered call or message is a customer who goes to your competitor. We install an assistant that answers for you 24/7, in Spanish and English, captures the customer details and books the appointment.',
          'Where do you lose more customers?'
        ]
      },
      chips: [
        { label: { es: '📞 En las llamadas', en: '📞 On calls' }, go: 'voz' },
        { label: { es: '💬 En los chats/mensajes', en: '💬 On chats/messages' }, go: 'chat' },
        { label: { es: '🔥 En los dos', en: '🔥 Both' }, go: 'combo' }
      ]
    },

    chat: {
      say: {
        es: [
          '🤖 Asistente de chat con IA: responde en tu página web y en WhatsApp, día y noche.',
          'Responde las preguntas de tus clientes, captura sus datos y agenda citas, en español e inglés. Instalación: $1,497. Y si quieres que lo gestionemos por ti, gestión mensual desde $197/mes.',
          '¿Seguimos?'
        ],
        en: [
          '🤖 AI chat assistant: it answers on your website and on WhatsApp, day and night.',
          'It answers your customers questions, captures their details and books appointments, in Spanish and English. Setup: $1,497. And if you want us to manage it for you, monthly management from $197/mo.',
          'Shall we continue?'
        ]
      },
      chips: [
        { label: { es: '✅ Quiero empezar', en: '✅ I want to start' }, go: 'califica1', cta: true },
        { label: { es: '💲 Ver todos los precios', en: '💲 See all prices' }, go: 'precios' },
        { label: { es: '↩️ Volver al inicio', en: '↩️ Back to start' }, go: 'root' }
      ]
    },

    voz: {
      say: {
        es: [
          '🗣️ Chat + Voz: todo lo del chat, más un asistente que CONTESTA TUS LLAMADAS con voz natural, en español e inglés, 24/7.',
          'Ninguna llamada cae al buzón: saluda con el nombre de tu negocio, responde lo básico, captura los datos y agenda. Instalación: $1,997. Gestión mensual desde $297/mes.',
          '¿Seguimos?'
        ],
        en: [
          '🗣️ Chat + Voice: everything in chat, plus an assistant that ANSWERS YOUR CALLS with a natural voice, in Spanish and English, 24/7.',
          'No call goes to voicemail: it greets with your business name, answers the basics, captures details and books. Setup: $1,997. Monthly management from $297/mo.',
          'Shall we continue?'
        ]
      },
      chips: [
        { label: { es: '✅ Quiero empezar', en: '✅ I want to start' }, go: 'califica1', cta: true },
        { label: { es: '💲 Ver todos los precios', en: '💲 See all prices' }, go: 'precios' },
        { label: { es: '↩️ Volver al inicio', en: '↩️ Back to start' }, go: 'root' }
      ]
    },

    combo: {
      say: {
        es: [
          '🔥 Perfecto: llamadas y chats cubiertos con el paquete Chat + Voz ($1,997 de instalación). Es la cubierta completa del «Método Sin Llamada Perdida».',
          'Te hago 3 preguntas rápidas y te llevo al formulario con todo claro:'
        ],
        en: [
          '🔥 Perfect: calls and chats covered with the Chat + Voice package ($1,997 setup). It is the full cover of the "Never Miss a Call Method".',
          'Let me ask you 3 quick questions and then take you to the form with everything clear:'
        ]
      },
      chips: [
        { label: { es: '✅ Empezar las 3 preguntas', en: '✅ Start the 3 questions' }, go: 'califica1', cta: true },
        { label: { es: '💲 Ver precios primero', en: '💲 See prices first' }, go: 'precios' }
      ]
    },

    web: {
      say: {
        es: [
          '🌐 Páginas web que venden, hechas para negocios hispanos:',
          '· Landing (una página que convierte): $993\n· Web completa de 5 páginas: $2,493\n· Cuidado web mensual: desde $99/mes (actualizaciones y seguridad)',
          'Toda web puede llevar su asistente de chat integrado, como este 😉'
        ],
        en: [
          '🌐 Websites that sell, made for Hispanic businesses:',
          '· Landing page (one page that converts): $993\n· Full 5-page website: $2,493\n· Monthly web care: from $99/mo (updates and security)',
          'Every website can include its own chat assistant, like this one 😉'
        ]
      },
      chips: [
        { label: { es: '✅ Quiero mi web', en: '✅ I want my website' }, go: 'califica1', cta: true },
        { label: { es: '💲 Ver todos los precios', en: '💲 See all prices' }, go: 'precios' },
        { label: { es: '↩️ Volver al inicio', en: '↩️ Back to start' }, go: 'root' }
      ]
    },

    precios: {
      say: {
        es: [
          '💲 Precios claros, sin letra pequeña:',
          '🤖 Chat con IA: $1,497 (instalación)\n🗣️ Chat + Voz: $1,997 (instalación)\n📋 Gestión mensual: $197 – $297/mes\n🌐 Landing: $993 · Web 5 páginas: $2,493\n🛡️ Cuidado web: $99 – $179/mes',
          'El paso serio se confirma al calificar: 50% adelantado y el resto al entregar. ¿Te llevo a calificar?'
        ],
        en: [
          '💲 Clear prices, no fine print:',
          '🤖 AI Chat: $1,497 (setup)\n🗣️ Chat + Voice: $1,997 (setup)\n📋 Monthly management: $197 – $297/mo\n🌐 Landing: $993 · 5-page website: $2,493\n🛡️ Web care: $99 – $179/mo',
          'The serious step is confirmed when you qualify: 50% upfront and the rest on delivery. Shall I take you to qualify?'
        ]
      },
      chips: [
        { label: { es: '✅ Calificar ahora', en: '✅ Qualify now' }, go: 'califica1', cta: true },
        { label: { es: '↩️ Volver al inicio', en: '↩️ Back to start' }, go: 'root' }
      ]
    },

    califica1: {
      say: {
        es: ['Pregunta 1 de 3: ¿qué tipo de negocio tienes?'],
        en: ['Question 1 of 3: what kind of business do you have?']
      },
      chips: [
        { label: { es: '🔧 Servicios / contratista', en: '🔧 Services / contractor' }, go: 'califica2' },
        { label: { es: '🍽️ Restaurante / comida', en: '🍽️ Restaurant / food' }, go: 'califica2' },
        { label: { es: '💈 Salón / belleza', en: '💈 Salon / beauty' }, go: 'califica2' },
        { label: { es: '🏪 Otro negocio', en: '🏪 Another business' }, go: 'califica2' }
      ]
    },
    califica2: {
      say: {
        es: ['Pregunta 2 de 3: ¿cuál es tu dolor número uno hoy?'],
        en: ['Question 2 of 3: what is your number one pain today?']
      },
      chips: [
        { label: { es: '📞 Pierdo llamadas', en: '📞 I miss calls' }, go: 'califica3' },
        { label: { es: '💬 No doy abasto con mensajes', en: '💬 I cannot keep up with messages' }, go: 'califica3' },
        { label: { es: '🌐 No tengo web (o está vieja)', en: '🌐 I have no website (or it is old)' }, go: 'califica3' },
        { label: { es: '🤷 Todo un poco', en: '🤷 A bit of everything' }, go: 'califica3' }
      ]
    },
    califica3: {
      say: {
        es: [
          'Pregunta 3 de 3: ¿ya tienes página web?',
          '(Con esto termino aquí: los datos personales se dejan solo en el formulario, nunca en el chat.)'
        ],
        en: [
          'Question 3 of 3: do you already have a website?',
          '(That is all I ask here: personal details go only in the form, never in the chat.)'
        ]
      },
      chips: [
        { label: { es: '✅ Sí, tengo web', en: '✅ Yes, I have one' }, go: 'cierre' },
        { label: { es: '❌ No tengo web', en: '❌ No website yet' }, go: 'cierre' }
      ]
    },
    cierre: {
      say: {
        es: [
          '🎉 Perfecto, ya tienes el panorama claro.',
          'El siguiente paso es contarnos los detalles de tu negocio en el formulario. Te respondemos en español, sin compromiso:'
        ],
        en: [
          '🎉 Perfect, now you have the full picture.',
          'The next step is telling us about your business in the form. We reply in Spanish, no pressure:'
        ]
      },
      chips: [
        { label: { es: '📝 Cuéntanos de tu negocio', en: '📝 Tell us about your business' }, url: '/contacto/', cta: true },
        { label: { es: '📰 De paso: nuestro noticiero', en: '📰 By the way: our newscast' }, go: 'puente_news' },
        { label: { es: '↩️ Volver al inicio', en: '↩️ Back to start' }, go: 'root' }
      ]
    },

    humano: {
      say: {
        es: [
          '🙋 Claro que sí. Una persona de la casa te atiende por estas vías:',
          '· Formulario: /contacto/ (la vía más rápida)\n· Correo: hola@yosmanydigital.com\n· Horario: lunes a sábado, 9 a. a 7 p.',
          'En el formulario cuéntanos de tu negocio y te respondemos con los pasos y el precio cerrado.'
        ],
        en: [
          '🙋 Of course. A person from the house can help you through:',
          '· Form: /contacto/ (the fastest path)\n· Email: hola@yosmanydigital.com\n· Hours: Monday to Saturday, 9 a. to 7 p.',
          'In the form, tell us about your business and we will reply with the steps and the final price.'
        ]
      },
      chips: [
        { label: { es: '📝 Ir al formulario', en: '📝 Go to the form' }, url: '/contacto/', cta: true },
        { label: { es: '🆘 Ayuda con mi compra', en: '🆘 Help with my purchase' }, go: 'ayuda' },
        { label: { es: '📰 De paso: nuestro noticiero', en: '📰 By the way: our newscast' }, go: 'puente_news' },
        { label: { es: '↩️ Volver al inicio', en: '↩️ Back to start' }, go: 'root' }
      ]
    },

    ayuda: {
      say: {
        es: [
          '¡Claro que te ayudo! 🙌 Así funciona la ayuda en esta casa:',
          '· Lo simple te lo respondo yo mismo, ahora mismo: precios, pasos o dónde está cada cosa.\n· Si es algo de tu cuenta o de tu paquete, escríbenos a hola@yosmanydigital.com: te responde una persona de la casa dentro de 24 horas (atención 24/7: escribe cuando sea).\n· Y si quieres resolver tú mismo, a tu ritmo, está la guía paso a paso de tu nivel: N1 $14.99 · N2 $24.99 · N3 $34.99 si la llevas con tu compra (después cuesta $5 más en cada nivel).',
          'Nadie se queda atascado aquí. ¿Por dónde empezamos?'
        ],
        en: [
          'Of course I can help! 🙌 Here is how help works in this house:',
          '· The simple stuff I answer myself, right now: prices, steps, or where things are.\n· If it is about your account or your package, email us at hola@yosmanydigital.com: a person from the house replies within 24 hours (24/7 support: write any time).\n· And if you want to solve it yourself, at your own pace, there is the step-by-step guide for your level: N1 $14.99 · N2 $24.99 · N3 $34.99 when you take it with your purchase (afterwards it costs $5 more at each level).',
          'Nobody gets stuck here. Where do we start?'
        ]
      },
      chips: [
        { label: { es: '✉️ Escribir al correo de ayuda', en: '✉️ Email the help desk' }, url: 'mailto:hola@yosmanydigital.com', cta: true },
        { label: { es: '📝 Ir al formulario', en: '📝 Go to the form' }, url: '/contacto/' },
        { label: { es: '↩️ Volver al inicio', en: '↩️ Back to start' }, go: 'root' }
      ]
    },

    tiempos: {
      say: {
        es: [
          '⏱️ Los tiempos exactos se confirman cuando calificas, según la carga de trabajo de esa semana: no te voy a prometer una fecha inventada.',
          'En el formulario te respondemos con el tiempo real de tu caso.'
        ],
        en: [
          '⏱️ Exact timelines are confirmed when you qualify, depending on that week workload: I will not promise you an invented date.',
          'In the form we reply with the real timeline for your case.'
        ]
      },
      chips: [
        { label: { es: '📝 Ir al formulario', en: '📝 Go to the form' }, url: '/contacto/', cta: true },
        { label: { es: '↩️ Volver al inicio', en: '↩️ Back to start' }, go: 'root' }
      ]
    },

    garantia: {
      say: {
        es: ['🛡️ Tenemos una página de garantía donde está todo por escrito. Te la dejo aquí:'],
        en: ['🛡️ We have a guarantee page where everything is in writing. Here it is:']
      },
      chips: [
        { label: { es: '🛡️ Ver la garantía', en: '🛡️ See the guarantee' }, url: '/garantia/', cta: true },
        { label: { es: '↩️ Volver al inicio', en: '↩️ Back to start' }, go: 'root' }
      ]
    },


    puente_news: {
      say: {
        es: [
          '📰 Y antes de irte, un regalo de la casa: este YCALMA nació en un noticiero.',
          'YOSMANY NEWS es nuestra casa madre: noticias sin filtro dos veces al día (7:00 a. m. y 7:00 p. m., hora del Este), series de historia, libros y clases gratuitas. Todo gratis, como siempre.',
          'Pásate cuando quieras:'
        ],
        en: [
          '📰 And before you go, a gift from the house: this YCALMA was born in a newscast.',
          'YOSMANY NEWS is our mother house: unfiltered news twice a day (7:00 a. and 7:00 p., Eastern), history series, books and free classes. All free, as always.',
          'Stop by any time:'
        ]
      },
      chips: [
        { label: { es: '📰 Visitar Yosmany News', en: '📰 Visit Yosmany News' }, url: 'https://yosmanynews.com/?utm_source=yosmanydigital&utm_medium=chat-puente' },
        { label: { es: '↩️ Volver al inicio', en: '↩️ Back to start' }, go: 'root' }
      ]
    },

    demo: {
      say: {
        es: [
          '😉 Justo eso: este chat que estás usando es una muestra viva de nuestro asistente.',
          'El tuyo respondería con la información de TU negocio: tus servicios, tus precios, tu horario, y capturaría a tus clientes igual que yo estoy conversando contigo.'
        ],
        en: [
          '😉 Exactly: this chat you are using is a live sample of our assistant.',
          'Yours would answer with YOUR business information: your services, your prices, your hours, and it would capture your customers just like I am chatting with you.'
        ]
      },
      chips: [
        { label: { es: '✅ Quiero el mío', en: '✅ I want mine' }, go: 'califica1', cta: true },
        { label: { es: '↩️ Volver al inicio', en: '↩️ Back to start' }, go: 'root' }
      ]
    }
  },

  faq: [
    { keys: ['precio', 'cuesta', 'cuestan', 'vale', 'valen', 'price', 'cost', 'how much'], node: 'precios' },
    { keys: ['llamada', 'llamadas', 'pierdo', 'pierde', 'telefono', 'teléfono', 'call', 'calls', 'missed', 'phone'], node: 'pierdo' },
    { keys: ['voz', 'voice', 'contesta llamada', 'answers calls'], node: 'voz' },
    { keys: ['whatsapp', 'chat', 'mensajes', 'messages'], node: 'chat' },
    { keys: ['web', 'pagina', 'página', 'website', 'landing', 'sitio'], node: 'web' },
    { keys: ['demora', 'tarda', 'tiempo', 'cuando esta', 'cuándo está', 'how long', 'timeline', 'fast'], node: 'tiempos' },
    { keys: ['garantia', 'garantía', 'guarantee', 'warranty'], node: 'garantia' },
    { keys: ['humano', 'persona', 'hablar con', 'human', 'person', 'real person'], node: 'humano' },
    { keys: ['ayuda', 'soporte', 'atascado', 'atascada', 'no funciona', 'no me funciona', 'problema con mi', 'help', 'support', 'stuck', 'not working', 'does not work'], node: 'ayuda' },
    { keys: ['demo', 'probar', 'prueba', 'ejemplo', 'sample', 'try'], node: 'demo' },
    { keys: ['empezar', 'comenzar', 'quiero', 'contratar', 'start', 'begin', 'sign up', 'hire'], node: 'califica1' }
  ]
};
