/* ============================================================
   YOSMANY DIGITAL — BANDA DELGADA ROTATIVA (maqueta delgada,
   14-nov-2026). Clon del formato de la banda de libros de la
   Casa Madre: rota las .bd-lamina cada 5 segundos; se pausa al
   pasar el cursor, al tocar y al enfocar; respeta
   «prefers-reduced-motion». Los puntos se crean solos según el
   número de láminas presentes en el HTML.
   ============================================================ */
(function () {
  "use strict";
  var pista = document.getElementById("bdPista");
  if (!pista) return;
  var laminas = pista.querySelectorAll(".bd-lamina");
  if (laminas.length < 2) return;
  var cajaPuntos = document.getElementById("bdPuntos");
  var puntos = [];
  if (cajaPuntos) {
    for (var p = 0; p < laminas.length; p++) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "bd-punto";
      b.setAttribute("aria-label", "Elegir anuncio");
      cajaPuntos.appendChild(b);
      puntos.push(b);
    }
  }
  var actual = 0;
  var timer = null;
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function pintar() {
    for (var i = 0; i < laminas.length; i++) {
      laminas[i].classList.toggle("activa", i === actual);
    }
    for (var j = 0; j < puntos.length; j++) {
      puntos[j].classList.toggle("activo", j === actual);
    }
  }
  function mostrar(n) {
    actual = ((n % laminas.length) + laminas.length) % laminas.length;
    pintar();
  }
  function auto() {
    if (reduce) return;
    detener();
    timer = setInterval(function () { mostrar(actual + 1); }, 5000);
  }
  function detener() {
    if (timer) { clearInterval(timer); timer = null; }
  }
  var prev = document.getElementById("bdPrev");
  var next = document.getElementById("bdNext");
  if (prev) prev.addEventListener("click", function () { mostrar(actual - 1); auto(); });
  if (next) next.addEventListener("click", function () { mostrar(actual + 1); auto(); });
  for (var k = 0; k < puntos.length; k++) {
    (function (idx) {
      puntos[idx].addEventListener("click", function () { mostrar(idx); auto(); });
    })(k);
  }
  var sec = document.getElementById("bandaDelgada");
  if (sec) {
    sec.addEventListener("mouseenter", detener);
    sec.addEventListener("mouseleave", auto);
    sec.addEventListener("focusin", detener);
    sec.addEventListener("focusout", auto);
    sec.addEventListener("touchstart", function () { detener(); }, { passive: true });
  }
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) detener(); else auto();
  });
  pintar();
  auto();
})();
