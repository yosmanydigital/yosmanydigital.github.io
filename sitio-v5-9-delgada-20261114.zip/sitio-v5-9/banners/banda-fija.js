/* ============================================================
   YOSMANY DIGITAL — BANDA FIJA DORADA ROTATIVA (banda PRO,
   14-nov-2026). La banda fija de arriba (.anuncio) rota sus
   4 mensajes (.bf-msg) con un fundido suave cada 8 segundos;
   se pausa al pasar el cursor, al tocar y al enfocar; respeta
   «prefers-reduced-motion» (sin rotación ni fundido) y se
   detiene con la pestaña oculta. Los textos viven en i18n.js
   (claves home.2, home.2b, home.2c, home.2d) con sus copias
   en línea en cada página; este guion solo cambia cuál
   mensaje se ve. Mismo patrón de la banda delgada.
   ============================================================ */
(function () {
  "use strict";
  var banda = document.querySelector(".anuncio");
  if (!banda) return;
  var msgs = banda.querySelectorAll(".bf-msg");
  if (msgs.length < 2) return;
  var actual = 0;
  var timer = null;
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function pintar() {
    for (var i = 0; i < msgs.length; i++) {
      msgs[i].classList.toggle("activa", i === actual);
    }
  }
  function mostrar(n) {
    actual = ((n % msgs.length) + msgs.length) % msgs.length;
    pintar();
  }
  function auto() {
    if (reduce) return;
    detener();
    timer = setInterval(function () { mostrar(actual + 1); }, 8000);
  }
  function detener() {
    if (timer) { clearInterval(timer); timer = null; }
  }
  banda.addEventListener("mouseenter", detener);
  banda.addEventListener("mouseleave", auto);
  banda.addEventListener("focusin", detener);
  banda.addEventListener("focusout", auto);
  banda.addEventListener("touchstart", function () { detener(); }, { passive: true });
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) detener(); else auto();
  });
  pintar();
  auto();
})();
