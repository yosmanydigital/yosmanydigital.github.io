/* ============================================================
   YOSMANY DIGITAL — MOTOR DE BANNERS ROTATIVOS (Fase 1)
   ------------------------------------------------------------
   Lee los datos de banners-data.js (window.YD_BANNERS_DATA) y
   monta la franja superior: rotación de 5 s con fundido, pausa
   al pasar el dedo/ratón o al enfocar, puntos de navegación,
   temporizador real en el banner de la promo y respeto a
   prefers-reduced-motion. Idioma: sigue el de la casa
   (localStorage "yd-lang" + evento "yd:idioma").
   También expone YDBanners.renderRejilla(el) pa' la página de
   revisión (todos los banners visibles, sin rotación).
   ============================================================ */
(function () {
  "use strict";

  var ROTACION_MS = 5000;
  var datos = Array.isArray(window.YD_BANNERS_DATA) ? window.YD_BANNERS_DATA : [];

  function idiomaActual() {
    var lang = null;
    try { lang = localStorage.getItem("yd-lang"); } catch (e) { /* modo privado */ }
    if (lang !== "es" && lang !== "en") lang = document.documentElement.lang || "es";
    return lang === "en" ? "en" : "es";
  }

  function t(campo, lang) {
    if (!campo) return "";
    if (typeof campo === "string") return campo;
    return campo[lang] || campo.es || "";
  }

  /* Un banner con temporizador vencido deja de mostrarse solo:
     la promo no se queda atrás aunque nadie toque el código. */
  function vigentes() {
    var ahora = Date.now();
    return datos.filter(function (b) {
      if (!b.countdownTo) return true;
      var fin = Date.parse(b.countdownTo);
      return isNaN(fin) || fin > ahora;
    });
  }

  function textoCuenta(b, lang) {
    var fin = Date.parse(b.countdownTo);
    if (isNaN(fin)) return "";
    var ms = fin - Date.now();
    if (ms <= 0) return "";
    var dias = Math.floor(ms / 86400000);
    var horas = Math.floor((ms % 86400000) / 3600000);
    var etiqueta = t(b.countdownLabel, lang);
    if (dias >= 1) {
      return etiqueta + " " + dias + (lang === "en" ? (dias === 1 ? " day" : " days") : (dias === 1 ? " día" : " días"));
    }
    return etiqueta + " " + Math.max(horas, 1) + (lang === "en" ? " h" : " h");
  }

  function crearSlide(b, lang, estatico) {
    var a = document.createElement(estatico ? "div" : "a");
    a.className = "ydb-slide";
    a.setAttribute("data-acento", b.acento || "gold");
    a.setAttribute("data-banner", b.id);
    if (!estatico) {
      a.href = b.href;
      a.setAttribute("role", "group");
      a.setAttribute("aria-roledescription", lang === "en" ? "slide" : "diapositiva");
      a.setAttribute("aria-label", t(b.titulo, lang) + (b.numero ? " " + t(b.numero, lang) : ""));
    }

    var texto = document.createElement("div");
    texto.className = "ydb-texto";

    var kicker = document.createElement("div");
    kicker.className = "ydb-kicker";
    kicker.textContent = t(b.kicker, lang);
    texto.appendChild(kicker);

    var titulo = document.createElement("div");
    titulo.className = "ydb-titulo";
    titulo.textContent = t(b.titulo, lang);
    if (b.numero && b.numeroEnTitulo) {
      var numT = document.createElement("span");
      numT.className = "ydb-numero";
      numT.textContent = t(b.numero, lang);
      titulo.appendChild(numT);
    }
    texto.appendChild(titulo);

    if (b.numero && !b.numeroEnTitulo) {
      var num = document.createElement("div");
      num.className = "ydb-numero";
      num.textContent = t(b.numero, lang);
      texto.appendChild(num);
    }

    var apoyo = document.createElement("div");
    apoyo.className = "ydb-apoyo";
    apoyo.textContent = t(b.apoyo, lang);
    texto.appendChild(apoyo);

    var fila = document.createElement("div");
    fila.className = "ydb-fila";
    var cta = document.createElement("span");
    cta.className = "ydb-cta";
    cta.textContent = t(b.cta, lang);
    fila.appendChild(cta);
    if (b.countdownTo) {
      var cuenta = document.createElement("span");
      cuenta.className = "ydb-count";
      cuenta.setAttribute("data-cuenta", b.id);
      cuenta.textContent = textoCuenta(b, lang);
      if (cuenta.textContent) fila.appendChild(cuenta);
    }
    texto.appendChild(fila);
    a.appendChild(texto);

    var foto = document.createElement("div");
    foto.className = "ydb-foto";
    var img = document.createElement("img");
    img.src = b.img;
    img.alt = t(b.imgAlt, lang);
    img.loading = estatico ? "eager" : "lazy";
    foto.appendChild(img);
    a.appendChild(foto);

    return a;
  }

  function montarFranja(contenedor) {
    var lang = idiomaActual();
    var lista = vigentes();
    if (!lista.length) { contenedor.style.display = "none"; return; }
    contenedor.innerHTML = "";
    contenedor.setAttribute("role", "region");
    contenedor.setAttribute("aria-roledescription", "carousel");
    contenedor.setAttribute("aria-label", lang === "en" ? "Offers and news" : "Ofertas y novedades");

    var slides = lista.map(function (b) {
      var s = crearSlide(b, lang, false);
      contenedor.appendChild(s);
      return s;
    });

    var puntos = document.createElement("div");
    puntos.className = "ydb-puntos";
    var botones = lista.map(function (b, i) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.setAttribute("aria-label", (lang === "en" ? "Go to banner " : "Ir al banner ") + (i + 1) + ": " + t(b.titulo, lang));
      btn.addEventListener("click", function () { irA(i, true); });
      puntos.appendChild(btn);
      return btn;
    });
    contenedor.appendChild(puntos);

    var actual = -1;
    var temporizador = null;
    var pausado = false;
    var reduceMov = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function pintar() {
      slides.forEach(function (s, i) {
        var activa = i === actual;
        s.classList.toggle("ydb-activa", activa);
        s.setAttribute("aria-hidden", activa ? "false" : "true");
        s.tabIndex = activa ? 0 : -1;
      });
      botones.forEach(function (btn, i) {
        btn.setAttribute("aria-current", i === actual ? "true" : "false");
      });
    }
    function irA(i, manual) {
      actual = (i + slides.length) % slides.length;
      pintar();
      if (manual) reiniciar();
    }
    function siguiente() { irA(actual + 1, false); }
    function arrancar() {
      if (temporizador || reduceMov || slides.length < 2) return;
      temporizador = setInterval(function () { if (!pausado) siguiente(); }, ROTACION_MS);
    }
    function reiniciar() {
      if (temporizador) { clearInterval(temporizador); temporizador = null; }
      arrancar();
    }
    ["pointerenter", "focusin"].forEach(function (ev) {
      contenedor.addEventListener(ev, function () { pausado = true; });
    });
    ["pointerleave", "focusout"].forEach(function (ev) {
      contenedor.addEventListener(ev, function () { pausado = false; });
    });
    /* Deslizar el dedo: siguiente / anterior */
    var x0 = null;
    contenedor.addEventListener("touchstart", function (e) {
      x0 = e.changedTouches[0].clientX;
    }, { passive: true });
    contenedor.addEventListener("touchend", function (e) {
      if (x0 === null) return;
      var dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 42) irA(actual + (dx < 0 ? 1 : -1), true);
      x0 = null;
    }, { passive: true });

    irA(0, false);
    arrancar();

    /* El temporizador de la promo se refresca cada minuto. */
    setInterval(function () {
      contenedor.querySelectorAll("[data-cuenta]").forEach(function (el) {
        var b = lista.filter(function (x) { return x.id === el.getAttribute("data-cuenta"); })[0];
        if (b) el.textContent = textoCuenta(b, idiomaActual());
      });
    }, 60000);
  }

  function montar() {
    var franja = document.getElementById("yd-banners");
    if (franja) montarFranja(franja);
    document.querySelectorAll("[data-yd-banners-rejilla]").forEach(function (el) {
      window.YDBanners.renderRejilla(el);
    });
  }

  window.YDBanners = {
    datos: datos,
    /* Rejilla estática pa' revisión: todos los banners, sin rotación. */
    renderRejilla: function (contenedor) {
      var lang = idiomaActual();
      contenedor.innerHTML = "";
      contenedor.classList.add("ydb-rejilla");
      vigentes().forEach(function (b) {
        contenedor.appendChild(crearSlide(b, lang, true));
      });
    },
    remontar: montar
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", montar);
  } else {
    montar();
  }
  /* La franja sigue el idioma de la casa. */
  document.addEventListener("yd:idioma", function () {
    var franja = document.getElementById("yd-banners");
    if (franja) montarFranja(franja);
    document.querySelectorAll("[data-yd-banners-rejilla]").forEach(function (el) {
      window.YDBanners.renderRejilla(el);
    });
  });
})();
