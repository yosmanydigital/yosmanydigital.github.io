/* ============================================================
   Chat de la casa — motor del widget (sin dependencias).
   - Botón flotante con la mascota, siempre presente.
   - Saludo proactivo a los ~6 s (globito, una vez por sesión).
   - Guía por pasos con botones (chips) usando flows.js de la casa.
   - Bilingüe ES/EN: detecta el idioma del navegador y el del
     mensaje del visitante; se puede cambiar con el toggle.
   - Texto libre: si flows.js trae "endpoint" (el Worker con la
     llave), pregunta a la IA; si no hay endpoint o falla, cae al
     modo guiado (FAQ por palabras clave + respuesta honesta).
   - No guarda datos personales: solo banderas de sesión.
   ============================================================ */
(function () {
  'use strict';
  var F = window.YD_CHAT_FLOWS;
  if (!F) { return; }

  var HOUSE = F.house || 'digital';
  var ENDPOINT = F.endpoint || '';
  var MAX_USER_MSGS = F.maxUserMsgs || 40;
  var PROACTIVE_MS = F.proactiveDelayMs || 6000;

  /* ---------- idioma ---------- */
  function detectLang() {
    try {
      var saved = sessionStorage.getItem('ydc-lang');
      if (saved === 'es' || saved === 'en') { return saved; }
    } catch (e) {}
    var nav = (navigator.language || 'es').toLowerCase();
    return nav.indexOf('es') === 0 ? 'es' : 'en';
  }
  var lang = detectLang();
  var ES_WORDS = ['hola', 'quiero', 'precio', 'cuanto', 'cuesta', 'gracias', 'negocio', 'llamadas', 'pagina', 'página', 'ver', 'cuando', 'cuándo', 'donde', 'dónde', 'libro', 'clase', 'si', 'sí', 'necesito', 'busco', 'ayuda', 'correo', 'telefono', 'teléfono'];
  var EN_WORDS = ['hello', 'hi', 'want', 'price', 'how', 'much', 'cost', 'thanks', 'business', 'calls', 'page', 'website', 'when', 'where', 'book', 'class', 'need', 'looking', 'help', 'email', 'phone', 'the', 'and', 'for', 'your'];
  function guessLang(text) {
    var t = ' ' + text.toLowerCase() + ' ', es = 0, en = 0, i, w;
    for (i = 0; i < ES_WORDS.length; i++) { w = ES_WORDS[i]; if (t.indexOf(' ' + w + ' ') >= 0 || t.indexOf(' ' + w + ',') >= 0 || t.indexOf(' ' + w + '?') >= 0) { es++; } }
    for (i = 0; i < EN_WORDS.length; i++) { w = EN_WORDS[i]; if (t.indexOf(' ' + w + ' ') >= 0 || t.indexOf(' ' + w + ',') >= 0 || t.indexOf(' ' + w + '?') >= 0) { en++; } }
    if (es > en + 1) { return 'es'; }
    if (en > es + 1) { return 'en'; }
    return null;
  }
  function L(obj) {
    if (typeof obj === 'string') { return obj; }
    return (obj && (obj[lang] || obj.es || obj.en)) || '';
  }
  var UI = {
    open:   { es: 'Abrir el chat de ayuda', en: 'Open the help chat' },
    close:  { es: 'Cerrar', en: 'Close' },
    send:   { es: 'Enviar', en: 'Send' },
    write:  { es: 'Escribe tu pregunta…', en: 'Type your question…' },
    online: { es: 'En línea · te guía paso a paso', en: 'Online · guides you step by step' },
    note:   { es: 'Asistente de la casa. Sin compromiso: explora con los botones.',
              en: 'House assistant. No pressure: explore with the buttons.' },
    chatBtn:{ es: 'Habla conmigo', en: 'Chat with me' },
    chatSub:{ es: 'Te guío paso a paso', en: 'I guide you step by step' },
    limit:  { es: 'Hemos conversado bastante por aquí 😊 Para seguir, lo mejor es el formulario de la casa o el correo: así te atiende una persona con todo el detalle.',
              en: 'We have covered a lot here 😊 To continue, the best path is the house form or email: a person can help you with full detail.' }
  };

  /* ---------- DOM ---------- */
  var root = document.createElement('div');
  root.className = 'ydc-root';
  root.setAttribute('data-house', HOUSE);

  var btn = document.createElement('button');
  btn.className = 'ydc-btn';
  btn.type = 'button';
  btn.setAttribute('aria-label', L(UI.open));
  btn.innerHTML = '<img src="' + F.mascot + '" alt="" width="46" height="46">' +
    '<span class="ydc-btn-txt">' + L(UI.chatBtn) + '<small>' + L(UI.chatSub) + '</small></span>';

  var pro = document.createElement('div');
  pro.className = 'ydc-pro ydc-hidden';
  pro.innerHTML = '<button class="ydc-pro-x" type="button" aria-label="' + L(UI.close) + '">✕</button>' +
    '<p>' + L(F.proactive) + '</p>' +
    '<button class="ydc-pro-cta" type="button">' + L(F.proactiveCta) + '</button>';

  var panel = document.createElement('section');
  panel.className = 'ydc-panel ydc-hidden';
  panel.setAttribute('aria-label', 'Chat');
  panel.innerHTML =
    '<div class="ydc-head">' +
      '<img src="' + F.mascot + '" alt="" width="40" height="40">' +
      '<div class="ydc-head-txt"><strong>' + L(F.assistantName) + '</strong><small>' + L(UI.online) + '</small></div>' +
      '<div class="ydc-lang"><button type="button" data-lang="es">ES</button><button type="button" data-lang="en">EN</button></div>' +
      '<button class="ydc-x" type="button" aria-label="' + L(UI.close) + '">✕</button>' +
    '</div>' +
    '<div class="ydc-msgs" role="log" aria-live="polite"></div>' +
    '<div class="ydc-chips"></div>' +
    '<form class="ydc-form"><input type="text" autocomplete="off" maxlength="600" placeholder="' + L(UI.write) + '" aria-label="' + L(UI.write) + '">' +
    '<button type="submit">' + L(UI.send) + '</button></form>' +
    '<div class="ydc-note">' + L(UI.note) + '</div>';

  root.appendChild(pro);
  root.appendChild(panel);
  root.appendChild(btn);
  document.body.appendChild(root);

  var msgsEl = panel.querySelector('.ydc-msgs');
  var chipsEl = panel.querySelector('.ydc-chips');
  var form = panel.querySelector('.ydc-form');
  var input = form.querySelector('input');
  var langBtns = panel.querySelectorAll('.ydc-lang button');

  var opened = false;
  var userCount = 0;
  var history = []; // {role, content} pa'l backend
  var sessionId = 's' + Math.random().toString(36).slice(2, 10);

  function scrollDown() { msgsEl.scrollTop = msgsEl.scrollHeight; }

  /* ---------- bloqueo del fondo + teclado (v5.1, móvil) ----------
     Al abrir el panel, la página de atrás NO se mueve: en iOS
     overflow:hidden solo no basta, así que el body queda
     position:fixed conservando el scrollY (ver CSS body.ydc-lock)
     y se restaura al cerrar. Solo en pantallas chicas: en
     escritorio el panel es una esquinita y la página puede rodar.
     Con visualViewport se ajusta la altura del panel (--ydc-vvh)
     y se levanta el root sobre el teclado (--ydc-kb), porque
     100dvh NO encoge cuando el teclado abre en iOS. */
  var lockedScrollY = null;
  function isSmallScreen() {
    try { return window.matchMedia('(max-width: 760px)').matches; }
    catch (e) { return false; }
  }
  function lockBackground() {
    if (lockedScrollY !== null || !isSmallScreen()) { return; }
    lockedScrollY = window.scrollY || window.pageYOffset || 0;
    document.body.style.top = (-lockedScrollY) + 'px';
    document.body.classList.add('ydc-lock');
  }
  function unlockBackground() {
    if (lockedScrollY === null) { return; }
    var y = lockedScrollY;
    lockedScrollY = null;
    document.body.classList.remove('ydc-lock');
    document.body.style.top = '';
    window.scrollTo(0, y);
  }
  var vv = window.visualViewport || null;
  function syncViewport() {
    var rs = document.documentElement.style;
    if (!vv || panel.classList.contains('ydc-hidden')) {
      rs.removeProperty('--ydc-vvh');
      rs.removeProperty('--ydc-kb');
      return;
    }
    rs.setProperty('--ydc-vvh', vv.height + 'px');
    var kb = Math.max(0, (window.innerHeight || 0) - vv.height);
    rs.setProperty('--ydc-kb', kb + 'px');
    scrollDown();
  }
  if (vv) {
    vv.addEventListener('resize', syncViewport);
    vv.addEventListener('scroll', syncViewport);
  }
  function addMsg(text, who) {
    var d = document.createElement('div');
    d.className = 'ydc-msg ' + who;
    d.innerHTML = linkify(escapeHtml(text));
    msgsEl.appendChild(d);
    scrollDown();
    return d;
  }
  function escapeHtml(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function linkify(s) {
    return s.replace(/(https?:\/\/[^\s<]+|\/[a-z0-9\-\/]*[a-z0-9\-\/])(\s|$)/gi, function (m, url, tail) {
      if (url.length < 2 || url === '/') { return m; }
      return '<a href="' + url + '">' + url.replace(/^https?:\/\//, '') + '</a>' + tail;
    });
  }
  var typingEl = null;
  function showTyping() {
    typingEl = document.createElement('div');
    typingEl.className = 'ydc-typing';
    typingEl.innerHTML = '<i></i><i></i><i></i>';
    msgsEl.appendChild(typingEl);
    scrollDown();
  }
  function hideTyping() { if (typingEl) { typingEl.remove(); typingEl = null; } }

  function setLang(newLang, silent) {
    if (newLang !== 'es' && newLang !== 'en') { return; }
    lang = newLang;
    try { sessionStorage.setItem('ydc-lang', lang); } catch (e) {}
    for (var i = 0; i < langBtns.length; i++) {
      langBtns[i].classList.toggle('on', langBtns[i].getAttribute('data-lang') === lang);
    }
    input.setAttribute('placeholder', L(UI.write));
    if (!silent && opened) { goNode('root', true); }
  }

  function renderChips(chips) {
    chipsEl.innerHTML = '';
    (chips || []).forEach(function (chip) {
      var el;
      if (chip.url) {
        el = document.createElement('a');
        el.className = 'ydc-chip' + (chip.cta ? ' cta' : '');
        el.href = chip.url;
        if (/^https?:/.test(chip.url)) { el.target = '_blank'; el.rel = 'noopener'; }
      } else {
        el = document.createElement('button');
        el.type = 'button';
        el.className = 'ydc-chip' + (chip.cta ? ' cta' : '');
        el.addEventListener('click', function () { goNode(chip.go); });
      }
      el.textContent = L(chip.label);
      chipsEl.appendChild(el);
    });
    scrollDown();
  }

  function goNode(nodeId, keepHistory) {
    var node = F.nodes[nodeId] || F.nodes.root;
    renderChips([]);
    showTyping();
    var say = node.say ? (node.say[lang] || node.say.es || []) : [];
    var delay = 420;
    setTimeout(function () {
      hideTyping();
      say.forEach(function (line) {
        addMsg(line, 'bot');
        history.push({ role: 'assistant', content: line });
      });
      renderChips(node.chips);
      if (!keepHistory) { /* el historial completo se mantiene pa'l backend */ }
    }, delay);
  }

  function openChat() {
    panel.classList.remove('ydc-hidden');
    pro.classList.add('ydc-hidden');
    btn.classList.add('ydc-hidden');
    lockBackground();
    syncViewport();
    if (!opened) {
      opened = true;
      setLang(lang, true);
      goNode('root', true);
    }
    // Auto-scroll al último mensaje al (re)abrir.
    setTimeout(scrollDown, 80);
    // En móvil NO auto-enfocar: abriría el teclado y taparía el
    // saludo antes de leerlo. El foco automático es solo con
    // puntero fino (mouse/trackpad).
    var finePointer = false;
    try { finePointer = window.matchMedia('(pointer: fine)').matches; } catch (e) {}
    if (finePointer) { setTimeout(function () { input.focus(); }, 60); }
  }
  function closeChat() {
    panel.classList.add('ydc-hidden');
    btn.classList.remove('ydc-hidden');
    unlockBackground();
    syncViewport();
  }

  btn.addEventListener('click', openChat);
  panel.querySelector('.ydc-x').addEventListener('click', closeChat);
  pro.querySelector('.ydc-pro-cta').addEventListener('click', openChat);
  pro.querySelector('.ydc-pro-x').addEventListener('click', function () {
    pro.classList.add('ydc-hidden');
    try { sessionStorage.setItem('ydc-pro-dismissed', '1'); } catch (e) {}
  });
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape' && opened && !panel.classList.contains('ydc-hidden')) { closeChat(); }
  });
  for (var i = 0; i < langBtns.length; i++) {
    langBtns[i].addEventListener('click', function () { setLang(this.getAttribute('data-lang')); });
  }
  setLang(lang, true);

  /* ---------- saludo proactivo ---------- */
  var proDismissed = false, proShown = false;
  try { proDismissed = sessionStorage.getItem('ydc-pro-dismissed') === '1'; } catch (e) {}
  setTimeout(function () {
    if (!opened && !proDismissed && !proShown) {
      proShown = true;
      pro.classList.remove('ydc-hidden');
    }
  }, PROACTIVE_MS);

  /* ---------- texto libre ---------- */
  function localAnswer(text) {
    var t = text.toLowerCase();
    var best = null, bestScore = 0;
    (F.faq || []).forEach(function (entry) {
      var score = 0;
      entry.keys.forEach(function (k) { if (t.indexOf(k) >= 0) { score += k.length; } });
      if (score > bestScore) { bestScore = score; best = entry; }
    });
    if (best && bestScore >= 4) { goNode(best.node, true); return; }
    showTyping();
    setTimeout(function () {
      hideTyping();
      addMsg(L(F.fallback), 'bot');
      history.push({ role: 'assistant', content: L(F.fallback) });
      renderChips((F.nodes.root && F.nodes.root.chips) || []);
    }, 500);
  }

  function backendAnswer(text) {
    var payload = {
      house: HOUSE, lang: lang, sessionId: sessionId,
      messages: history.slice(-10)
    };
    var ctrl = ('AbortController' in window) ? new AbortController() : null;
    var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, 12000) : null;
    fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: ctrl ? ctrl.signal : undefined
    }).then(function (r) {
      if (timer) { clearTimeout(timer); }
      if (!r.ok) { throw new Error('bad'); }
      return r.json();
    }).then(function (data) {
      hideTyping();
      if (data && data.reply) {
        addMsg(data.reply, 'bot');
        history.push({ role: 'assistant', content: data.reply });
        renderChips((F.nodes.root && F.nodes.root.chips) || []);
      } else { localAnswer(text); }
    }).catch(function () {
      if (timer) { clearTimeout(timer); }
      hideTyping();
      localAnswer(text);
    });
  }

  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    var text = input.value.trim();
    if (!text) { return; }
    input.value = '';
    var guessed = guessLang(text);
    if (guessed && guessed !== lang) { setLang(guessed, true); }
    addMsg(text, 'user');
    history.push({ role: 'user', content: text });
    userCount++;
    if (userCount > MAX_USER_MSGS) {
      showTyping();
      setTimeout(function () {
        hideTyping();
        addMsg(L(UI.limit), 'bot');
        renderChips(F.limitChips ? (F.limitChips[lang] || F.limitChips) : []);
      }, 500);
      return;
    }
    if (ENDPOINT) { showTyping(); backendAnswer(text); }
    else { localAnswer(text); }
  });
})();
