/* ============================================================
   YOSMANY DIGITAL — DATOS DE LOS BANNERS ROTATIVOS (Fase 1)
   ------------------------------------------------------------
   FUENTE DE NÚMEROS: ~/workspace/yosmany-digital/REGISTRO-PROMOS.md
   Ningún número entra aquí si no está en el registro.
   Actualizar un banner = editar este archivo (datos), no el motor.
   Textos ES (canónicos) + EN (gemelos), como el resto de la casa.
   ============================================================ */
window.YD_BANNERS_DATA = [
  {
    id: "chat-promo",
    negocio: "Chat IA · Promoción vigente",
    img: "/banners/img/mascota-chat-promo.webp",
    imgAlt: {
      es: "Ycalma, la mascota de Yosmany Digital, celebrando la oferta",
      en: "Ycalma, the Yosmany Digital mascot, celebrating the offer"
    },
    kicker: { es: "ASISTENTE DE CHAT CON IA", en: "AI CHAT ASSISTANT" },
    titulo: { es: "Primeros 5 negocios: tu asistente instalado por", en: "First 5 businesses: your assistant installed for" },
    numero: { es: "$599", en: "$599" },
    numeroEnTitulo: true,
    apoyo: { es: "TODO con −20 % durante los primeros 6 meses", en: "EVERYTHING with 20% off during the first 6 months" },
    cta: { es: "Quiero mi asistente", en: "Get my assistant" },
    href: "/chat-ia/",
    acento: "gold",
    /* Temporizador real: fin de la ventana de lanzamiento (REGISTRO §3).
       Al vencer, el motor deja de mostrar este banner solo. */
    countdownTo: "2027-05-14T23:59:59-04:00",
    countdownLabel: { es: "La ventana cierra en", en: "The window closes in" }
  },
  {
    id: "chat-voz",
    negocio: "Chat IA · Chat + Voz",
    img: "/banners/img/mascota-chat-voz.webp",
    imgAlt: {
      es: "Ycalma hablando por teléfono, como el asistente de voz",
      en: "Ycalma talking on the phone, like the voice assistant"
    },
    kicker: { es: "CHAT + VOZ CON IA", en: "AI CHAT + VOICE" },
    titulo: { es: "Tu asistente que contesta y habla por ti", en: "Your assistant that answers and talks for you" },
    numero: { es: "$1,997", en: "$1,997" },
    apoyo: { es: "Instalación completa · Gestión desde $197/mes", en: "Full installation · Management from $197/mo" },
    cta: { es: "Conoce el chat + voz", en: "See chat + voice" },
    href: "/chat-voz-ia/",
    acento: "coral"
  },
  {
    id: "web-landing",
    negocio: "Páginas web · Landing",
    img: "/banners/img/mascota-web-landing.webp",
    imgAlt: {
      es: "Ycalma presentando una página de aterrizaje",
      en: "Ycalma presenting a landing page"
    },
    kicker: { es: "PÁGINAS WEB", en: "WEBSITES" },
    titulo: { es: "Una landing que convierte visitas en clientes", en: "A landing page that turns visits into customers" },
    numero: { es: "$993", en: "$993" },
    apoyo: { es: "Página de aterrizaje profesional, lista pa' vender", en: "Professional landing page, ready to sell" },
    cta: { es: "Quiero mi landing", en: "Get my landing" },
    href: "/landing/",
    acento: "gold"
  },
  {
    id: "web-completa",
    negocio: "Páginas web · Web completa",
    img: "/banners/img/mascota-web-completa.webp",
    imgAlt: {
      es: "Ycalma construyendo una web completa",
      en: "Ycalma building a complete website"
    },
    kicker: { es: "PÁGINAS WEB", en: "WEBSITES" },
    titulo: { es: "Tu web completa, lista pa' vender", en: "Your complete website, ready to sell" },
    numero: { es: "$2,493", en: "$2,493" },
    apoyo: { es: "5 páginas · diseño profesional · en tu idioma", en: "5 pages · professional design · in your language" },
    cta: { es: "Quiero mi web", en: "Get my website" },
    href: "/paginas-web/",
    acento: "coral"
  },
  {
    id: "web-mantenida",
    negocio: "Páginas web · Instalada y mantenida",
    img: "/banners/img/mascota-web-mantenida.webp",
    imgAlt: {
      es: "Ycalma con un escudo dorado: tu web protegida y mantenida",
      en: "Ycalma with a golden shield: your website protected and maintained"
    },
    kicker: { es: "WEB INSTALADA Y MANTENIDA", en: "WEBSITE INSTALLED & MAINTAINED" },
    titulo: { es: "Nosotros la instalamos y la mantenemos por ti", en: "We install it and maintain it for you" },
    numero: { es: "$99–$179/mes", en: "$99–$179/mo" },
    apoyo: { es: "Cuidado web: actualizaciones, respaldo y ajustes", en: "Web care: updates, backups and tweaks" },
    cta: { es: "Ver cómo funciona", en: "See how it works" },
    href: "/precios/",
    acento: "gold"
  },
  {
    id: "anunciate",
    negocio: "Anúnciate (puente a la Casa Madre)",
    img: "/banners/img/mascota-anunciate.webp",
    imgAlt: {
      es: "Ycalma con un megáfono anunciando tu negocio",
      en: "Ycalma with a megaphone announcing your business"
    },
    kicker: { es: "ANÚNCIATE", en: "ADVERTISE WITH US" },
    titulo: { es: "Promociónate en nuestros videos", en: "Get featured in our videos" },
    numero: null,
    apoyo: { es: "Tu negocio frente a la audiencia de Yosmany News", en: "Your business in front of the Yosmany News audience" },
    cta: { es: "Conoce la Casa Madre", en: "Visit the main house" },
    href: "https://yosmanynews.com/",
    acento: "coral"
  },
  {
    id: "companero",
    negocio: "Compañero personal YCALMA (sin precios: aún no sellados)",
    img: "/banners/img/mascota-companero.webp",
    imgAlt: {
      es: "Ycalma saludando con ternura, con un corazón dorado",
      en: "Ycalma waving tenderly, holding a golden heart"
    },
    kicker: { es: "COMPAÑERO PERSONAL", en: "PERSONAL COMPANION" },
    titulo: { es: "YCALMA: tu compañero, tu apoyo", en: "YCALMA: your companion, your support" },
    numero: null,
    apoyo: { es: "Un asistente personal que te acompaña a tu manera", en: "A personal assistant that keeps you company, your way" },
    cta: { es: "Quiero saber más", en: "Tell me more" },
    href: "/contacto/",
    acento: "gold"
  }
];
